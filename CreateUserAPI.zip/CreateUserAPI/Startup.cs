using CreateUserAPI.Data;
using CreateUserAPI.Global;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CreateUserAPI
{
    public class Startup
    {
        private IWebHostEnvironment _env;
        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            _env = env;
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers();

            configureDatabase(services);

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(name: "v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "My API", Version = "v1" });

                c.AddSecurityDefinition(GlobalSetting.ApiKeyHeaderName, new OpenApiSecurityScheme
                {
                    Description = "Api key needed to access the endpoints. ApiKey: <API_VALUE>",
                    In = ParameterLocation.Header,
                    Name = GlobalSetting.ApiKeyHeaderName,
                    Type = SecuritySchemeType.ApiKey
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Name = GlobalSetting.ApiKeyHeaderName,
                Type = SecuritySchemeType.ApiKey,
                In = ParameterLocation.Header,
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = GlobalSetting.ApiKeyHeaderName
                },
             },
             new string[] {}
         }
    });
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();

            app.UseSwaggerUI(c=>
            {

                c.SwaggerEndpoint(url:"/swagger/v1/swagger.json", name:"My API V1");
            });



            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        private void configureDatabase(IServiceCollection services)
        {
            var connStr = Configuration.GetConnectionString("DefaultConnection");
            string dataSource = getDataSource(connStr);

            configureSqlLite(services, dataSource);

        }

        private string getDataSource(string connStr)
        {
            var pieces = from p in connStr.Split(";")
                         select p.Trim();
            var dataSources = from p in pieces
                              where p.StartsWith("Data Source")
                              select p.Split("=")[1];
            return dataSources.FirstOrDefault();

        }

        private void configureSqlLite(IServiceCollection services, string fileName)
        {
            var rootDir = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            rootDir = rootDir.Replace(@"file:\", "");
            var filePath = rootDir + Path.DirectorySeparatorChar + fileName;

            var filePath1 = "./LocalDB/" + fileName;
            //var filePath = _env.ContentRootPath + Path.DirectorySeparatorChar + fileName;
            var connStr = $"Filename={filePath1}";
            services.AddDbContext<UserContext>(options =>
                options.UseSqlite(connStr));
        }
    }
}
