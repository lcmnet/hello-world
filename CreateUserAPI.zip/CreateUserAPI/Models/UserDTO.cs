﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CreateUserAPI.Models
{
    public class UserDTO
    {
        public long Id { get; set; }
    }
}
