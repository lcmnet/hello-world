﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CreateUserAPI.Models
{
    public class User
    {
        public long Id { get; set; }

        [StringLength(20, ErrorMessage = "Value for {0} should not be more than {1} characters")]
        [DisplayName("Full Name")]
        [JsonPropertyName("fullName")]
        [Required]
        public string Name { get; set; }

        [StringLength(20, ErrorMessage = "Value for {0} should not be more than {1} characters")]
        [Required]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }


        [StringLength(10, ErrorMessage = "{0} should not be more than {1} characters")]
        public string Phone { get; set; }



        [Range(1, 1000,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int? Age { get; set; }
    }
}
