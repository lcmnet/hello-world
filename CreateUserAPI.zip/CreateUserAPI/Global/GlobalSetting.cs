﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CreateUserAPI.Global
{
    public static class GlobalSetting
    {
        public static readonly string FriendlyErrorMessage = "There was an error. Please come back later.....";
        public static readonly string ApiKeyHeaderName = "ApiKey";
    }
}
