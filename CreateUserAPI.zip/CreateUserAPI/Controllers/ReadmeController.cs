﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateUserAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ReadmeController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<ReadmeController> _logger;

        public ReadmeController(ILogger<ReadmeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public ContentResult Get()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<div>");
            sb.Append("Please use the ApiKey for all REST API calls. The api key is provided to you in my email.");
            sb.Append("<BR/>");
            sb.Append("<BR/>");
            sb.Append("You can use the <a href='swagger'>swagger UI</a> for the API documentation.");
            sb.Append("</div>");


            return base.Content(sb.ToString(), "text/html");
        }
    }
}
