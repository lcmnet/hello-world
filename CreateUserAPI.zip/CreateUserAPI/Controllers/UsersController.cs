﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CreateUserAPI.Data;
using CreateUserAPI.Models;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;
using CreateUserAPI.Global;
using CreateUserAPI.Attributes;
using Microsoft.Data.Sqlite;

namespace CreateUserAPI.Controllers
{
    [ApiKeyAuth]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly ILogger<UsersController> _logger;
        private readonly UserContext _context;

        public UsersController(UserContext context, ILogger<UsersController> logger)
        {
            _logger = logger;
            _context = context;
        }

        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            string methodName = "GetUsers";
            _logger.LogDebug("{0}", methodName);

            try
            {
                return await _context.Users.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return CustomErrorStatus();
            }
            finally
            {
                _logger.LogDebug("{0}.....completed", methodName);
            }

        }

        // GET: api/Search
        [HttpGet("Search")]
        public async Task<ActionResult<IEnumerable<User>>> Search(string email, string phone)
        {
            string methodName = "Search";
            _logger.LogDebug("{0}", methodName);

            try
            {
                bool useOriginalSourceData = false;
                IQueryable<User> results = null;

                //filtering based on criteria
                if (!string.IsNullOrEmpty(email))
                {
                    results = _context.Users.Where(e => e.Email.Contains(email));
                }
                else
                {
                    useOriginalSourceData = true;
                }

                if (!string.IsNullOrEmpty(phone))
                {
                    results = useOriginalSourceData ? _context.Users : results;
                    results = results.Where(e => e.Phone.Contains(phone));
                }

                //sorting based on criteria
                if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(phone))
                {
                    results = results.OrderBy(c => c.Email).ThenBy(n => n.Phone);
                }
                else if (!string.IsNullOrEmpty(email))
                {
                    results = results.OrderBy(c => c.Email);
                }
                else if (!string.IsNullOrEmpty(phone))
                {
                    results = results.OrderBy(c => c.Phone);
                }

                if (results is null)
                {
                    results = new User[] { }.AsQueryable();
                    return results.ToList();
                }
                else
                {
                    return await results.ToListAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return CustomErrorStatus();
            }
            finally
            {
                _logger.LogDebug("{0}.....completed", methodName);
            }

        }

        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(long id)
        {
            string methodName = "GetUser";
            _logger.LogDebug("{0}", methodName);

            try {

                var user = await _context.Users.FindAsync(id);

                if (user == null)
                {
                    return NotFound();
                }

                return user;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return CustomErrorStatus();
            }
            finally {
                _logger.LogDebug("{0}.....completed", methodName);
            }


            
        }

        // PUT: api/Users/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUser(long id, User user)
        {
            string methodName = "PutUser";
            _logger.LogDebug("{0}", methodName);

            try
            {
                if (id != user.Id)
                {
                    return BadRequest();
                }

                _context.Entry(user).State = EntityState.Modified;

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return CustomErrorStatus();
            }
            finally {
                _logger.LogDebug("{0}.....completed", methodName);
            }
        }

        // POST: api/Users
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<User>> PostUser(User user)
        {
            string methodName = "PutUser";
            _logger.LogDebug("{0}", methodName);

            try
            {
                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetUser", new { id = user.Id }, UserToDTO(user));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return CustomErrorStatus();
            }
            finally
            {
                _logger.LogDebug("{0}.....completed", methodName);
            }
        }

        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<User>> DeleteUser(long id)
        {
            string methodName = "DeleteUser";
            _logger.LogDebug("{0}", methodName);

            try
            {
                var user = await _context.Users.FindAsync(id);
                if (user == null)
                {
                    return NotFound();
                }

                _context.Users.Remove(user);
                await _context.SaveChangesAsync();

                return user;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return CustomErrorStatus();
            }
            finally
            {
                _logger.LogDebug("{0}.....completed", methodName);
            }
        }

        [HttpDelete("All")]
        public async Task<ActionResult<bool>> DeleteAll()
        {
            string methodName = "DeleteAll";
            _logger.LogDebug("{0}", methodName);

            try
            {
                SqliteParameter x = new SqliteParameter { ParameterName = "@id", Value = 0};
                await _context.Database.ExecuteSqlRawAsync("Delete from [Users] where id > @id", x);
                return Ok(true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return CustomErrorStatus();
            }
            finally
            {
                _logger.LogDebug("{0}.....completed", methodName);
            }
        }

        private bool UserExists(long id)
        {
            return _context.Users.Any(e => e.Id == id);
        }


        private static UserDTO UserToDTO(User user) =>
        new UserDTO
        {
            Id = user.Id,

        };

        private ObjectResult CustomErrorStatus() => StatusCode(StatusCodes.Status500InternalServerError, GlobalSetting.FriendlyErrorMessage);
        
    }
}
